const {WEB_DOMAIN , TEST_DOMAIN} =process.env
const AuthIpAddress = {
        origin: WEB_DOMAIN,         
};

module.exports = AuthIpAddress;